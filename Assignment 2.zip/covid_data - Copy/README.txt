Guide
	First, start in the Main.java file
	Then, choose option (you can keep continiously choosing the option until you click finish)
	Whenever which option is chosen, the java file will be run (E.g Choose Summart, choose to group and calculate, the Summary.java file will be run)
	Note that, whenever option show chart is used, the image of the chart will be shown in the covid_data file

Youtube link of Presentation video: https://youtu.be/p6Fml6Ara5o

Github link for code: https://github.com/DungLe2001/Assignment2

Contribution   

Dung Le (+2) (s3915085): Leader, in charge of Summary part, assigns work for memebers, brainstorming the assignment by drawing diagram.

Dat Nguyen (-1) (s3894433): In charge of Display part and Main part, in charge of communicating with the professor for help.

Hoang Dang (-1) (s3927241): In charge of Data part, helping memebers with their assigned work.


